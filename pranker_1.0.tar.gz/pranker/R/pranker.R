## estimates binary classification performance against random
## input:
## "scores" -> scores of belonging to positive class
## "y" -> positive class different than 0, negative class 0
## "params" (optional) -> mean and variance of null distribution (obtained in the function "null.params")
## "approx" (optional) -> logical value indicating whether a spline interpolation approximation is used
## "approxN" (optional, integer) -> parameter of the approximation, the higher the faster (default P/10)
## maximum of approxN is P (should be a bad approximation), minimum is 1 (no approximation)

## comment this to build package ##

## Rcppc functions for null parameters 
#library(Rcpp)
#Sys.setenv("PKG_CXXFLAGS"="-fopenmp")
#Sys.setenv("PKG_LIBS"="-fopenmp")
#cores <- parallel::detectCores()
#sourceCpp("cFiles.cpp")
#sourceCpp("cFiles-omp.cpp")

pranker <- function(scores,y,params,approx,approxN){
	estimate.p=FALSE
	if (missing(params)){
		estimate.p=TRUE}
	if (missing(approx)){
		approx=TRUE}
	if (missing(approxN)){
		approxN=round(0.5+length(which(y!=0))/10)} ## P/10 (the higher the faster!)
	ranking=as.numeric(scores)
	y=as.numeric(y)
	P=length(which(y!=0))
	N=length(y)	
	print("computing auprc (average precision)")##
	auprc=auprc.ap( scores, y)
	if (estimate.p==TRUE){
		print("computing parameters of null distribution:") ## 
		params=null.params(N,P,approx,approxN)
		}
	nullMEAN=params[1]
	nullVAR=params[2] 
	print("beta fitting")
	k=1:P
	min.possible=sum(k/(N-P+k)*(1/P))
	a=min.possible
	b=1	
	mean.beta=(nullMEAN-a)/(b-a)
	var.beta=nullVAR/(b-a)^2
	par1=mean.beta^2*((1-mean.beta)/var.beta)-mean.beta
	par2=par1*(1/mean.beta)-par1
	auprc=(auprc-a)/(b-a) 
	pv=pbeta(auprc,par1,par2, lower.tail=FALSE)
	names(params) <- c("mean","var")
	out <- list(auprc = auprc*(b-a)+a, pvalue = pv, nullparams = params, instances = c(total = N, P = P))	
	return(out)
	}

## average precision auprc ##
auprc.ap<- function(scores,y) { 
			# rank
			ranked=sort(as.numeric(scores),decreasing=TRUE,index.return=TRUE)			
			P=length(which(y!=0))
			Total=length(y)
			precisions=NULL
			tp_count=0
			for (i in 1:Total){
				## is a true positive?
				if (y[ranked[[2]][i]]!=0){
					tp_count=tp_count+1						
					precisions=c(precisions, (tp_count/i))
					}
				}
			out=mean(precisions)
			return(out)
			}

## null distribution parameters
null.params <- function(N,P,approx,approxN){
	if (missing(approx)){
		approx=TRUE}
	if (missing(approxN)){
		approxN=round(0.5+(P/10))}
	print("mean")
	nullMEAN=expectVAL(N,P)
	print("variance")
	if (approx==FALSE){
		## put symmetric ##
		nullCOV=covMAT(N,P)
		varDIAG=diag(nullCOV)
		nullCOV=nullCOV+t(nullCOV)
		diag(nullCOV)=varDIAG
		}
	if (approx==TRUE){
		nullCOV=covMATF(N,P,approxN)}
	nullVAR=sum(nullCOV) ## 
	out=c(nullMEAN, nullVAR)
	return(out)
	}


## covariance (faster version)
## for each k, estimates the covariance between k and j, where j is considered at a rate given by 1/approxN
covMATF<-function(N,P,approxN){
	cMAT=covMATFAST(N,P,approxN);
	diagC=diag(cMAT)
	indADD=which(t(cMAT)!=0)
	cMAT[indADD]=t(cMAT)[indADD]
	diag(cMAT)=diagC
	cMATi=cMAT
	for (k in 1:(P-1)){
		indx=which(cMAT[k,]!=0)
		xout=1:P
		## spline interpolation:
		## remove problematic non decreasing covariances - rare but it can happen
		ind.prob=which(diff(cMAT[k,indx])>0)
		if (length(ind.prob)>0){
			xout=setdiff(xout, 1:max(indx[ind.prob]))
			indx=indx[-ind.prob]}		
		newpoints=spline(indx, cMAT[k,indx], xout=xout, method="hyman")[[2]]
		cMATi[k, xout]=newpoints
		}	
	### add missing possible values 
	cMATi[which(cMATi==0)]=t(cMATi)[which(cMATi==0)]
	return(cMATi)
	}
	
### get an auprc from a z-score ###
qAUPRC <- function(N, P, nullMEAN, nullVAR, zscore){	
	k=1:P
	min.possible=sum(k/(N-P+k)*(1/P))
	a=min.possible
	b=1
	mean.beta=(nullMEAN-a)/(b-a)
	var.beta=nullVAR/(b-a)^2
	par1=mean.beta^2*((1-mean.beta)/var.beta)-mean.beta
	par2=par1*(1/mean.beta)-par1
	
	pvalue=pnorm(zscore,0,1,lower.tail=FALSE)
	betaval=qbeta(pvalue, par1, par2, lower.tail=FALSE)
	auprc=betaval*(b-a) + a	
	#betaval=(auprc-a)/(b-a) 
	return(auprc)}
