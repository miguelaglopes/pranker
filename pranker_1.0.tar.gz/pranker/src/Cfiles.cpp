// Rcppc functions for null parameters 

// non parallel version
// in order to use parallel computing via OpenMP
// http://wbnicholson.wordpress.com/2014/07/10/parallelization-in-rcpp-via-openmp/ 
// uncomment all lines "#pragma omp parallel for"
// and #include <omp.h>

#include <Rcpp.h>
//#include <omp.h>
#include <iostream>
using namespace Rcpp;
using namespace std;

// expected value ##	
// [[Rcpp::export]]
double expectVAL(IntegerVector Ni, IntegerVector Pi) {
int N=as<int>(Ni);
int P=as<int>(Pi);
std::vector<double> logvals(N+1,0);
double eVALUE=0;
for (int i=1; i<N+1; i++){
	logvals[i]=log(i);
	}
for (int k=1; k<P+1; k++){
	Rcpp::Rcout << ".";
	for (int n=k; n<N+1; n++){
		double hyp=(long double)(R::dhyper(k-1,P,N-P,n-1,1))+logvals[P-k+1]-logvals[N-n+1]+logvals[k]-logvals[n];
		hyp=exp(hyp);
		eVALUE=eVALUE+hyp;
		}
	}
eVALUE=eVALUE/P;
Rcpp::Rcout << " done " << endl;
return(eVALUE);
}

// covariance
// [[Rcpp::export]] 
NumericMatrix covMAT(IntegerVector Ni, IntegerVector Pi){

int N=as<int>(Ni);
int P=as<int>(Pi);
std::vector<double> ekMULT(N, 0);
std::vector<double> out(P, 0);
std::vector<double> ek(P, 0);
std::vector<double> ek2(P, 0);
std::vector<double> inv(N+1, 0);
std::vector<double> mult1(N+1,0);
std::vector<double> logvals(N+1,0);
Rcpp::NumericMatrix ekjALL(P,P);
Rcpp::NumericMatrix covMAT(P,P);
double ekSUM;
double ekSUM2;
for (int i=1; i<N+1; i++){
	inv[i]=(long double)(1)/i;
	}
for (int i=1; i<N+1; i++){
	mult1[i]=(long double)(i-1)/((N-i+1)*i);
	}
for (int i=1; i<N+1; i++){
	logvals[i]=log(i);
	}
for (int k = 1; k<P+1; k++ ) {	
	Rcpp::Rcout << ".";
	// expected value for k and expected value square
	ekSUM=0;
	ekSUM2=0;
	for (int nk=k; nk<(N-P+k+1); nk++) {	
		ekMULT[nk-1]=(long double)R::dhyper(k-1,P-1,N-P,nk-1,1)+logvals[k]-logvals[nk]-logvals[P]-logvals[N];	
		ekMULT[nk-1]=exp(ekMULT[nk-1]);
		ekSUM=ekSUM+(ekMULT[nk-1]*P);
		ekSUM2=ekSUM2+(ekMULT[nk-1]*k/nk);
		}
	ek[k-1]=ekSUM;
	ek2[k-1]=ekSUM2;	
	
	if (k<P){
	//#pragma omp parallel for 
	for (int j = k+1; j<(P+1); j++){
		double ekj=0;
		long double ekjMULT;
		long double ekjMULT2;
		long unsigned int MULT1;
		int nk=k;
		int nj=nk+j-k;
		ekjMULT=(long double)(R::dhyper(j-k-1,P-k-1,N-nk-P+k,nj-nk-1,1))-logvals[nj]+logvals[P-k]+logvals[j]-logvals[N-nk];
		ekjMULT=exp(ekjMULT);					
		ekjMULT2=ekjMULT*ekMULT[nk-1];
		ekj=ekj+ekjMULT2;
		for (nj=nk+j-k+1; nj<(N-P+j+1); nj++) {
			MULT1=(N-nj-P+j+1)*(nj-nk-1);
			ekjMULT2=ekjMULT2*mult1[nj]*MULT1*inv[nj-nk-j+k];					
			ekj=ekj+ekjMULT2;
			}		
		for (nk=k+1; nk<(N-P+k+1); nk++) {	
			nj=nk+j-k;
			MULT1=(N-nj-P+j+1)*(N-nk+1);
			ekjMULT=ekjMULT*mult1[nj]*MULT1*inv[N-nk+1-P+k];												
			ekjMULT2=ekjMULT*ekMULT[nk-1];
			ekj=ekj+ekjMULT2;						
			for (nj=nk+j-k+1; nj<(N-P+j+1); nj++) {
				MULT1=(N-nj-P+j+1)*(nj-nk-1);
				ekjMULT2=ekjMULT2*mult1[nj]*MULT1*inv[nj-nk-j+k];						
				ekj=ekj+ekjMULT2;
				}
			}	
		ekjALL(k-1,j-1)=ekj;
		}}
	}
for (int k = 1; k<P; k++ ) {	
	for (int j = k+1; j<(P+1); j++){
		covMAT(k-1,j-1)=ekjALL(k-1,j-1)-(ek[k-1]*ek[j-1]);
		}
	}	
for (int k = 1; k<P+1; k++ ) {	
	covMAT(k-1,k-1)=ek2[k-1]-(ek[k-1]*ek[k-1]);
	}
Rcpp::Rcout << " done " << endl;
return(covMAT);
}


// [[Rcpp::export]] 
NumericMatrix covMATFAST(IntegerVector Ni, IntegerVector Pi, IntegerVector approxNi){

int N=as<int>(Ni);
int P=as<int>(Pi);
std::vector<double> inv(N+1, 0);
std::vector<double> mult1(N+1,0);
std::vector<double> logvals(N+1,0);
Rcpp::NumericMatrix ekjALL(P,P);
Rcpp::NumericMatrix covMAT(P,P);
std::vector<double> ek(P, 0);
std::vector<double> ek2(P, 0);
int approxN=as<int>(approxNi);

for (int i=1; i<N+1; i++){
	inv[i]=(long double)(1)/i;
	}
for (int i=1; i<N+1; i++){
	mult1[i]=(long double)(i-1)/((N-i+1)*i);
	}
for (int i=1; i<N+1; i++){
	logvals[i]=log(i);
	}

for (int k = 1; k<P+1; k++ ) {	
	Rcpp::Rcout << ".";
	// expected value for k and expected value square
	std::vector<double> ekMULT(N, 0);
	double ekSUM=0;
	double ekSUM2=0;
	for (int nk=k; nk<(N-P+k+1); nk++) {	
		ekMULT[nk-1]=(long double)R::dhyper(k-1,P-1,N-P,nk-1,1)+logvals[k]-logvals[nk]-logvals[P]-logvals[N];	
		ekMULT[nk-1]=exp(ekMULT[nk-1]);
		ekSUM=ekSUM+(ekMULT[nk-1]*P);
		ekSUM2=ekSUM2+(ekMULT[nk-1]*k/nk);
		}
	ek[k-1]=ekSUM;
	ek2[k-1]=ekSUM2;
	if (k<P){

	//#pragma omp parallel for 
	for (int j = k+1; j<P+1; j++){
		
		int c=(j-k-1)%approxN;
		if (((c==0)||(j==P))||(k==1)){
		
		double ekj=0;
		long double ekjMULT;
		long double ekjMULT2;
		long unsigned int MULT1;
		int nk=k;
		int nj=nk+j-k;
		ekjMULT=(long double)(R::dhyper(j-k-1,P-k-1,N-nk-P+k,nj-nk-1,1))-logvals[nj]+logvals[P-k]+logvals[j]-logvals[N-nk];
		ekjMULT=exp(ekjMULT);					
		ekjMULT2=ekjMULT*ekMULT[nk-1];
		ekj=ekj+ekjMULT2;
		for (nj=nk+j-k+1; nj<(N-P+j+1); nj++) {
			MULT1=(N-nj-P+j+1)*(nj-nk-1);
			ekjMULT2=ekjMULT2*mult1[nj]*MULT1*inv[nj-nk-j+k];					
			ekj=ekj+ekjMULT2;
			}		
		for (nk=k+1; nk<(N-P+k+1); nk++) {	
			nj=nk+j-k;
			MULT1=(N-nj-P+j+1)*(N-nk+1);
			ekjMULT=ekjMULT*mult1[nj]*MULT1*inv[N-nk+1-P+k];												
			ekjMULT2=ekjMULT*ekMULT[nk-1];
			ekj=ekj+ekjMULT2;						
			for (nj=nk+j-k+1; nj<(N-P+j+1); nj++) {
				MULT1=(N-nj-P+j+1)*(nj-nk-1);
				ekjMULT2=ekjMULT2*mult1[nj]*MULT1*inv[nj-nk-j+k];						
				ekj=ekj+ekjMULT2;
				}
			}	
		ekjALL(k-1,j-1)=ekj;
		}}}
	}
for (int k = 1; k<P; k++ ) {	
	int counter=approxN-1;
	for (int j = k+1; j<(P+1); j++){
		counter++;
		if (((counter==approxN)||(j==P))||(k==1)){
			counter=0;
			covMAT(k-1,j-1)=ekjALL(k-1,j-1)-(ek[k-1]*ek[j-1]);
			}}}
				
for (int k = 1; k<P+1; k++ ) {	
	covMAT(k-1,k-1)=ek2[k-1]-(ek[k-1]*ek[k-1]);
	}
Rcpp::Rcout << " done " << endl;
return(covMAT);
}
