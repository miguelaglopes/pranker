covFUN <-
function(N,P,i){
		X1=P*(P-1)/(N*(N-1))
		X2=X1*(P-2)/(N-2)
		X3=X2*(P-3)/(N-3)	
		ni=i	
		minJ=(i+1)
		maxJ=N
		snj=(maxJ-minJ+1)*(minJ+maxJ)/2 # sum(nj)
		Nnj=maxJ-minJ+1 # length(nj)
		harmS=(digamma(maxJ+1)-digamma(minJ))	
		## covariance: EXY-EXEY
		## EXEY ## 
		ETPi2=ni*(P/N)*(1+(P-1)*(ni-1)/(N-1))
		ETPiTPiprev=X1*(ni-1)*(-1+ni+(N-1)/(P-1))
		ETPj2=(P/N)*Nnj+X1*snj-X1*Nnj		
		ETPjTPjprev=X1*snj+Nnj*X1*(((N-1)/(P-1)-1)-1)-X1*((N-1)/(P-1)-1)*harmS
		EXEY=( ETPi2-ETPiTPiprev)*(ETPj2-ETPjTPjprev)/(ni*P^2)
		## EXY ##	
		K1=ni*(X1+(ni-1)*X2)  
		K2=ni*(X2+(ni-1)*X3)
		K3=ni*(X1+3*(ni-1)*X2+(ni-1)*(ni-2)*X3)	 
		K4=ni*(X1+7*(ni-1)*X1+6*(ni-1)*(ni-2)*X2+(ni-1)*(ni-2)*(ni-3)*X3)
		K5=(ni-1)*(X1+(ni-2)*X2+X2)
		K6=(ni-1)*(X2+(ni-2)*X3+X3)				
		K7=(ni-1)*(X1+7*(ni-2)*X1+6*(ni-2)*(ni-3)*X2+(ni-2)*(ni-3)*(ni-4)*X3)		
		K8=(ni-1)*X1
		K9=3*(ni-1)*(X1+3*(ni-2)*X2+(ni-2)*(ni-3)*X3)
		K10=3*(ni-1)*(X1+(ni-2)*X2)		
		K11=(ni-1)*(X1+3*(ni-2)*X2+(ni-2)*(ni-3)*X3+3*X2+2*(ni-2)*X3)
	    ETPi2TPj2=K1*Nnj-K1*ni*harmS+K2*(snj-(2*ni+1)*Nnj+ni*(ni+1)*harmS)+K4*harmS+K3*2*Nnj-K3*2*ni*harmS		
		ETPi2TPjTPjprev=K1*(Nnj-harmS-ni*harmS)+K2*(snj-(2*ni+3)*Nnj+(ni+1)*(ni+2)*harmS)+K4*harmS+K3*2*(Nnj-(ni+1)*harmS)+K2*(Nnj-(ni+1)*harmS)+K3*harmS
		ETPiTPiprevTPj2=K5*Nnj-K5*ni*harmS+K6*(snj-(2*ni+1)*Nnj+ni*(ni+1)*harmS)+(K7+K8+K9+K10)*harmS+2*K11*(Nnj-ni*harmS)
		ETPiTPiprevTPjprevTPj=K5*(Nnj-harmS-ni*harmS)+K6*(snj-(2*ni+3)*Nnj+(ni+1)*(ni+2)*harmS)+(K7+K8+K9+K10)*harmS+2*K11*(Nnj-harmS-ni*harmS)+K6*(Nnj-harmS-ni*harmS)+K11*harmS
		EXY=(ETPi2TPj2-ETPi2TPjTPjprev-ETPiTPiprevTPj2+ETPiTPiprevTPjprevTPj)/(ni*P^2) 
		covXY=EXY-EXEY
		return(covXY)
		}
