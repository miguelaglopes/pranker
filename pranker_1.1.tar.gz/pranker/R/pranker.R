pranker <-
function(scores,groundtruth,params){
	estimate.p=FALSE
	if (missing(params)){
		estimate.p=TRUE}
	if(!is.numeric(scores)){stop("'scores' must be numeric")}
	if(!is.numeric(groundtruth)){stop("'groundtruth' must be numeric")}
	if(length(groundtruth)!=length(scores)){stop("'groundtruth' and 'scores' must be of the same length")}
	if(!missing(params)){
		if(length(params)!=2){stop("'params' must be of length 2'")}
		if(!all(is.numeric(params))){stop("'params' must be a numeric vector'")}}		
	
	y=groundtruth
	ranking=as.numeric(scores)
	y=as.numeric(y)
	P=length(which(y!=0))
	N=length(y)	
	print("computing auprc (average precision)")##
	auprc=auprc( scores, y)
	if (estimate.p==TRUE){
		print("computing parameters of null distribution:") ## 
		params=numeric(2)
		print("expected value...")
		params[1]=EVauprc(N,P)
		print("variance...")
		params[2]=VARauprc(N,P)
		print("done")
		}
	nullMEAN=params[1]
	nullVAR=params[2] 
	print("beta fitting")
	k=1:P
	min.possible=sum(k/(N-P+k)*(1/P))
	a=min.possible
	b=1	
	mean.beta=(nullMEAN-a)/(b-a)
	var.beta=nullVAR/(b-a)^2
	par1=mean.beta^2*((1-mean.beta)/var.beta)-mean.beta
	par2=par1*(1/mean.beta)-par1
	auprc=(auprc-a)/(b-a) 
	pv=pbeta(auprc,par1,par2, lower.tail=FALSE)
	names(params) <- c("mean","var")
	out <- list(auprc = auprc*(b-a)+a, pvalue = pv, nullparams = params, instances = c(total = N, P = P))	
	return(out)
	}
