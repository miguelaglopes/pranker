EVauprc <-
function(N,P){
	numSel=1:N
	numSelprev=c(0,numSel[-N])
	X1=P*(P-1)/(N*(N-1))
	EX=sum(((numSel*(P/N)+numSel*(numSel-1)*X1)-(numSelprev*(numSel*X1-X1+P/N)))/(numSel*P))
	return(EX)}
