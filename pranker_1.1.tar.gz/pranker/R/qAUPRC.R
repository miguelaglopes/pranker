qAUPRC <-
function(N, P, nullMEAN, nullVAR, zscore){	
	k=1:P
	min.possible=sum(k/(N-P+k)*(1/P))
	a=min.possible
	b=1
	mean.beta=(nullMEAN-a)/(b-a)
	var.beta=nullVAR/(b-a)^2
	par1=mean.beta^2*((1-mean.beta)/var.beta)-mean.beta
	par2=par1*(1/mean.beta)-par1
	
	pvalue=pnorm(zscore,0,1,lower.tail=FALSE)
	betaval=qbeta(pvalue, par1, par2, lower.tail=FALSE)
	auprc=betaval*(b-a) + a	
	#betaval=(auprc-a)/(b-a) 
	return(auprc)}
