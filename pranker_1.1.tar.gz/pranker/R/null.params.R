null.params <-
function(N,P){
	nullMEAN=EVauprc(N,P)
	nullVAR=VARauprc(N,P)
	return( c(nullMEAN, nullVAR))
	}
