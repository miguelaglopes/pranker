varFUN <-
function(N,P,ni){	
		X1=P*(P-1)/(N*(N-1))
		X2=X1*(P-2)/(N-2)
		X3=X2*(P-3)/(N-3)		
		ETPi4=ni*((P/N)+7*(ni-1)*X1+6*(ni-1)*(ni-2)*X2+(ni-1)*(ni-2)*(ni-3)*X3)		
		ETPi3TPiprev=(ni-1)*X1 + 3*(ni-1)*(X1+(ni-2)*X2) + 3*(ni-1)*(X1+3*(ni-2)*X2+(ni-2)*(ni-3)*X3) + P/N*(ni-1)+7*(ni-1)*(ni-2)*X1+6*(ni-1)*(ni-2)*(ni-3)*X2+(ni-1)*(ni-2)*(ni-3)*(ni-4)*X3
		ETPi2TPiprev2=(ni-1)*X1*(1+(ni-2)*(P-2)/(N-2))+(ni-1)*(P/N+7*(ni-2)*X1+6*(ni-2)*(ni-3)*X2+(ni-2)*(ni-3)*(ni-4)*X3)+2*(ni-1)*(X1+3*(ni-2)*X2+(ni-2)*(ni-3)*X3)		
		EX2=(ETPi4-2*ETPi3TPiprev+ETPi2TPiprev2)/(ni^2*P^2)
		EXEX=((ni*(P/N)+ni*(ni-1)*X1 - (ni-1)*(ni-1+(N-1)/(P-1))*X1)/(ni*P))^2
		varX=(EX2-EXEX)		
		return(varX)
		}
