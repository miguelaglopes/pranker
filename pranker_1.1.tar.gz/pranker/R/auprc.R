auprc <-
function(scores, groundtruth){
	rankedScores=sort(scores, index.return=TRUE, decreasing=TRUE)[[2]]
	groundtruth[which(groundtruth!=0)]=1
	## algorithm: 
	TPS=cumsum(groundtruth[rankedScores])
	precision=TPS/(1:length(groundtruth))
	recall=TPS/length(which(groundtruth!=0))
	weight=diff(c(0,recall))
	auprc=sum(precision*weight)
	return(auprc)}
