VARauprc <-
function(N,P){	
	## sum of covariances of each term i with all the other terms 
	iall=1:(N-1)
	sumCOVi=covFUN(N,P,iall)
	covmatSUM=2*sum(sumCOVi) ## symmetric matrix 
	
	## variances of each term i
	iall=1:N
	VARi=varFUN(N,P,iall)
	covmatSUM=covmatSUM+sum(VARi)
	return(covmatSUM)
	}
